module.exports = function () {
	for(var i = 0; i<10000;i++);
    console.log('a function in file foo');
};