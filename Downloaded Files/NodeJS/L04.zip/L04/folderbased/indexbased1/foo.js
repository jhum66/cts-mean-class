var bar = require('./bar');
bar.bar1();
bar.bar2();