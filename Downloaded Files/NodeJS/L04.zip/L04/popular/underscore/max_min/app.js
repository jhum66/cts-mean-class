var _ = require('underscore');
var numbers = [10, 5, 100, 2, 1000];
console.log(_.min(numbers)); // 2 
console.log(_.max(numbers)); // 1000 
