var config = require('./config');
console.log(config.foo); // this is the value for foo