var bar = require('bar');
bar(); // hello node_modules!