var a = 15;
var b = "15";
var c = new String("15");
console.log(a==b);
console.log(a===b);
console.log(b==c);
console.log(b===c);
var e = "15";
console.log(b==e);
console.log(b===e);
var d = new String("15");
c
b
d
console.log(c==d);
d
console.log(c===d);
