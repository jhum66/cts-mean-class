var a = [];
a.push(1);
a.push("23");
for(var i = 0; i < a.length ; i++) {console.log("a value is "+a[i]; }
for(var i = 0; i < a.length ; i++) {console.log("a value is "+a[i]); }
