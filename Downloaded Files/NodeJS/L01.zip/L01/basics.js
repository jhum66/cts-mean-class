var a = 12;
console.log(typeof a)
var b = true;
console.log(typeof b)
var c = 'Y';
console.log(typeof c)
var d = "Z";
console.log(typeof d)
var e = [];
console.log(typeof e)
var f = {};
console.log(typeof f)
