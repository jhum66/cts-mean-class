var foo = {
    bar: 123
};
console.log(foo); // { bar: 123 }
