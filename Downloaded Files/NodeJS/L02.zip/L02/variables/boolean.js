var foo = true;
console.log(foo); // true

// Boolean operations (&&, ||, !) work as expected:
console.log(true && true);  // true 
console.log(true && false); // false
console.log(true || false); // true 
console.log(false || false); // false
console.log(!true); // false 
console.log(!false); // true
