var foo = 123;
console.log(foo); // 123