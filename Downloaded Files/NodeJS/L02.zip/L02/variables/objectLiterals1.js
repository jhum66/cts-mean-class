var foo = {};
console.log(foo); // {}
foo.bar = 123; // extend foo 
console.log(foo); // { bar: 123 }
