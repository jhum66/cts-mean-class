setTimeout(function () {
    console.log('2000 milliseconds have passed since this demo started');
}, 2000);
