console.log('' == '0'); // false
console.log(0 == ''); // true

console.log('' === '0'); // false
console.log(0 === ''); // false
