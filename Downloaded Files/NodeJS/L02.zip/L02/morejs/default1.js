var foo;
console.log(foo); // undefined
