console.log(process.argv);
for(var i = 0; i<process.argv.length; i++)
	console.log("Value of "+i+" = "+process.argv[i]);