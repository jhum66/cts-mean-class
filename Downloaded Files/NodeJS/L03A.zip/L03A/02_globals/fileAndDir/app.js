console.log(__dirname);
console.log(__filename); 

console.log(typeof __dirname);

//console.log(__filename===module.filename);