define(['../node/amdmodule'], function (amdmodule) {
});