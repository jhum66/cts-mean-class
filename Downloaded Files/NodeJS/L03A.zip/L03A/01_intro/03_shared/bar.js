var foo = require('./foo');
console.log('in another module:', foo.something); // 456

