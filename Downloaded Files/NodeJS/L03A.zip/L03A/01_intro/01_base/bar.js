var foo = require('./foo');
foo(); // logs out : "a function in file foo"
